/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jerseytutorial.services;

import com.mycompany.jerseytutorial.models.Account;
import com.mycompany.jerseytutorial.models.Customer;
import com.mycompany.jerseytutorial.models.Transaction;
import static com.mycompany.jerseytutorial.models.Transaction.TransactionType.LODGEMENT;
import static com.mycompany.jerseytutorial.models.Transaction.TransactionType.TRANSFER;
import static com.mycompany.jerseytutorial.models.Transaction.TransactionType.WITHDRAWAL;
import java.util.ArrayList;
import java.util.List;

public class TransactionService {
     public static List<Transaction> list  = new ArrayList<>();
     public static boolean init = true;
     
     
       public TransactionService(){
        if(init){
            Transaction t1 = new Transaction(LODGEMENT, 1234.00, "01/01/2022", "Lodging new year savings");
            Transaction t2 = new Transaction(WITHDRAWAL, 2000.00, "25/12/2022", "Withdrawing Xmas bonus");
            Transaction t3 = new Transaction(TRANSFER, 500.00, "25/12/2022", "Transferring Xmas present to Wife");
            Transaction t4 = new Transaction(LODGEMENT, 5000.00, "31/01/2022", "Lodging local lottery winnings");

            
            
            list.add(t1);
            list.add(t2);
            list.add(t3);
            list.add(t4);
            init=false;
        }
    }
     
     
     
     
     
     
     
    
    public List<Transaction> getAllTransactions(int cid, int aid){
       
          return null;
    }
    
    
    //method to lodge transaction to customer account by account number
    public Transaction makeLodgement(int cid, int aid, Transaction t){
       
        return null;
    }
    
    //method to withdraw transaction from account by account number
    public Transaction makeWithdrawal(int cid, int aid, Transaction t){
       
        return null;
    }
    
    //method to withdraw transaction from customer account and lodge to recipient account
    public Transaction makeTransfer(int cid, int aid,int recipientCustId, int recipientAccId, Transaction t){
        System.out.println("Transferring "+t.getAmount()+" from "+cid+": "+aid+" to: "+recipientCustId + " :"+recipientAccId);
        if(makeWithdrawal(cid,aid,t) == t){
        makeLodgement(recipientCustId,recipientAccId,t);
        return t;
        }
        return null;
    }
    
    }
