/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jerseyProject.resources;

import com.mycompany.jerseyProject.models.Customer;
import com.mycompany.jerseyProject.models.Account;
import com.mycompany.jerseyProject.services.AccountService;

import com.mycompany.jerseyProject.models.Transaction;
import com.mycompany.jerseyProject.models.Transaction.TransactionType;
import com.mycompany.jerseyProject.services.CustomerService;
import static com.mycompany.jerseyProject.services.TransactionService.list;
import com.mycompany.jerseyProject.services.TransactionService;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.QueryParam;




@Path("/transactions")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)

public class TransactionResource{

    private TransactionService transactionService = new TransactionService();
 
   
  
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public List <Transaction> getTransactionJSON(){
        return list;  
    }
    
    
 
    
    @GET
    @Path("/{transactionID}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
     public Transaction getTransaction(@PathParam("transactionID") int transactionID) {
        return transactionService.getTransaction(transactionID);
        }
    }

