package com.mycompany.jerseyProject.resources;

import javax.xml.bind.annotation.XmlRootElement;
import com.mycompany.jerseyProject.models.Customer;
import com.mycompany.jerseyProject.services.CustomerService;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.QueryParam;
import com.mycompany.jerseyProject.models.Account;
import com.mycompany.jerseyProject.services.AccountService;
/**
 *
 * @author caoimheRuddy
 */
@Path("/accounts")
public class AccountResource {
    
    AccountService accountService = new AccountService();
    
  
    
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public List <Account> getAccountsJSON(){
        return accountService.getAllAccounts();  
    }
    
    
    @GET
    @Path("/{accountID}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
     public Account getAccount(@PathParam("accountID") int accountID) {
        return accountService.getAccount(accountID);
        }
}

